<?php
function tgwhiteboard_add_instance(stdClass $data,mod_tgwhiteboard_mod_form $mform = null)
{
	global $DB, $session;	
		$value0=$data->course = (int) $data->course;
		$value1=$data->name;	
		$value2=$data->presenter_id;	
		//$value3=$user->sessionkey;
		$value6=$data->startdt;
		$value7=$data->enddt;
		$value3=(mt_rand(0,10000000));
		
		$livesessiondetails=(object)array('course'=>$value0,'name'=>$value1,'presenter_id'=>$value2,'tg_sessionkey'=>$value3,'tg_start_datetime'=>$value6,'tg_end_datetime'=>$value7);
		$session = $DB->insert_record('tgwhiteboard',$livesessiondetails);			
		
		$value5=$DB->get_field('tgwhiteboard', 'id', array ('tg_sessionkey' => $value3));
	
		foreach($data->types as $student_list)
		{				
		$studentdetails=(object)array('tg_studentid'=>$student_list,'tgwhiteboard_id'=>$value5);
		$students = $DB->insert_record('tg_students',$studentdetails);
		}
		return $session;
	};
function tgwhiteboard_update_instance(stdClass $data,mod_tgwhiteboard_mod_form $mform = null)
{
	global $DB, $session;
	$data->id = $data->instance;
	$data->intro=$data->instance;
	$data->introformat=$data->instance;
	$data->timemodified=time();		
	$data->name = $data->name;
	//$data->tg_sessionkey = $data->sessionkey;
	$data->presenter_id = $data->presenter_id;
	$data->tg_start_datetime = $data->startdt;
	echo $data->tg_end_datetime = $data->enddt;
	$data->tg_sessionkey=(mt_rand(0,10000000));
    $dataid = $DB->update_record('tgwhiteboard', $data);
	
	$value10=$DB->delete_records('tg_students', array ('tgwhiteboard_id' => $data->id));
	
	foreach($data->types as $student_list)
		{		
		$update_studentdetails=(object)array('tg_studentid'=>$student_list,'tgwhiteboard_id'=>$data->id);
		$update_students = $DB->insert_record('tg_students',$update_studentdetails);
		}
	$updatedtgrecord = $DB->get_record('tgwhiteboard', array('id' => $data->instance));    
	return $dataid;
};
	 
function tgwhiteboard_delete_instance()
{};