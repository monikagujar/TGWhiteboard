<?php
// This file is part of TGCampusWhiteboard - https://www.tgcampus.com/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Library of interface functions and constants for module tgwhiteboard
 *
 * All the core Moodle functions, neeeded to allow the module to work
 * integrated in Moodle should be placed here.
 * All the tgwhiteboard specific functions, needed to implement all the module
 * logic, should go to locallib.php. This will help to save some memory when
 * Moodle is performing actions across all modules.
 *
 * @package    mod_tgwhiteboard
 * @copyright  https://www.tgcampus.com/
 * @author     monika.gujar@greenpointglobal.com
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
function tgwhiteboard_add_instance(stdClass $data,mod_tgwhiteboard_mod_form $mform = null)
{
	global $DB, $session;	
		$value0=$data->course = (int) $data->course;
		$value1=$data->name;	
		$value2=$data->presenter_id;	
		$value6=$data->startdt;
		$value8=$data->tg_duration;
		$value3=uniqid($value2,true);
		
		$livesessiondetails=(object)array('course'=>$value0,'name'=>$value1,'presenter_id'=>$value2,'tg_sessionkey'=>$value3,'tg_start_datetime'=>$value6,'tg_duration'=>$value8);
		$session = $DB->insert_record('tgwhiteboard',$livesessiondetails);			
		
		$value5=$DB->get_field('tgwhiteboard', 'id', array ('tg_sessionkey' => $value3));
	
		foreach($data->types as $student_list)
		{				
		$studentdetails=(object)array('tg_studentid'=>$student_list,'tgwhiteboard_id'=>$value5);
		$students = $DB->insert_record('tg_students',$studentdetails);
		}
		return $session;
		var_dump($session);
	};
function tgwhiteboard_update_instance(stdClass $data,mod_tgwhiteboard_mod_form $mform = null)
{
	global $DB, $session;
	$data->id = $data->instance;
	$data->intro=$data->instance;
	$data->introformat=$data->instance;
	$data->timemodified=time();		
	$data->tg_start_datetime = $data->startdt;
    $dataid = $DB->update_record('tgwhiteboard', $data);
	
	$value10=$DB->delete_records('tg_students', array ('tgwhiteboard_id' => $data->id));
	
	foreach($data->types as $student_list)
		{		
		$update_studentdetails=(object)array('tg_studentid'=>$student_list,'tgwhiteboard_id'=>$data->id);
		$update_students = $DB->insert_record('tg_students',$update_studentdetails);
		}
	$updatedtgrecord = $DB->get_record('tgwhiteboard', array('id' => $data->instance));    
	return $dataid;
};
	 
function tgwhiteboard_delete_instance($id)
{
	global $DB, $CFG;
    require_once($CFG->dirroot.'/mod/tgwhiteboard/locallib.php');

    if (!$tgwhiteboard = $DB->get_record('tgwhiteboard', array('id'=>$id))) {
        return false;
    }
    $DB->delete_records('tgwhiteboard', array('id'=>$tgwhiteboard->id));
	$DB->delete_records('tg_students', array('tgwhiteboard_id'=>$tgwhiteboard->id));
    return true;
};