<?php
defined('MOODLE_INTERNAL') || die();

function tgwhiteboard_getteacherdetail() {
    global $DB;
      $sql  = "SELECT u.id,u.username FROM {course} c ";
     $sql .= "JOIN {context} ct ON c.id = ct.instanceid ";
     $sql .= "JOIN {role_assignments} ra ON ra.contextid = ct.id ";
     $sql .= "JOIN {user} u ON u.id = ra.userid ";
     $sql .= "JOIN {role} r ON r.id = ra.roleid ";
     $sql .= "WHERE ra.roleid in (1,2,3,4)";
     $teacherlist = $DB->get_records_sql($sql);
    return $teacherlist;
}

function tgwhiteboard_getstudentdetail() {
    global $DB;
      $sql  = "SELECT u.id,u.username FROM {course} c ";	  
     $sql .= "JOIN {context} ct ON c.id = ct.instanceid ";
     $sql .= "JOIN {role_assignments} ra ON ra.contextid = ct.id ";
     $sql .= "JOIN {user} u ON u.id = ra.userid ";
     $sql .= "JOIN {role} r ON r.id = ra.roleid ";
     $sql .= "WHERE ra.roleid = 5";
     $studentlist = $DB->get_records_sql($sql);
    return $studentlist;
}