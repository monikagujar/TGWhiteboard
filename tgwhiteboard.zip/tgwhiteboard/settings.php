<?php
// This file is part of TGCampus Whiteboard - https://www.tgcampus.com/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * tgwhiteboard module admin settings and defaults
 *
 * @package    mod_tgwhiteboard
 * @subpackage tgwhiteboard
 * @copyright  https://www.tgcampus.com/
 * @author     monika.gujar@greenpointglobal.com
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
 
 
 
if ($ADMIN->fulltree) {
	
    $settings->add(new admin_setting_heading('tgwhiteboard_method_heading', get_string('generalconfig', 'tgwhiteboard'),
                       get_string('explaingeneralconfig', 'tgwhiteboard')));

	$settings->add(new admin_setting_configtext('tgwhiteboard_client_name', get_string('client_name', 'tgwhiteboard'),
						get_string('license_key_desc', 'tgwhiteboard'), '', PARAM_TEXT));

    $settings->add(new admin_setting_configtext('tgwhiteboard_license_key', get_string('license_key', 'tgwhiteboard'),
                       get_string('license_key_desc', 'tgwhiteboard'), '', PARAM_TEXT));
					   
    $settings->add(new admin_setting_configtext('tgwhiteboard_room_name', get_string('room_name', 'tgwhiteboard'),
                       get_string('room_name_desc', 'tgwhiteboard'), '', PARAM_TEXT));
					   
					   $settings->add(new admin_setting_configtext('tgwhiteboard_is_secured', get_string('is_secured', 'tgwhiteboard'),
						get_string('license_key_desc', 'tgwhiteboard'), '', PARAM_INT));
					   
    $str = '<center><img src="'.$CFG->wwwroot.'/mod/tgwhiteboard/pix/tgcampus-logo.png"/></center><br />';
    $settings->add(new admin_setting_heading('tgwhiteboard_logo', '', $str));
    $settings->add(new admin_setting_heading('tgwhiteboard_desc', '', get_string('setting_discription', 'tgwhiteboard')));
}

$PAGE->requires->jquery();