<?php
// This file is part of TGCampusWhiteboard - https://www.tgcampus.com/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.


/**
 * English strings for tgwhiteboard
 *
 * You can have a rather longer description of the file as well,
 * if you like, and it can span multiple lines.
 *
 * @package    mod_tgwhiteboard
 * @copyright  https://www.tgcampus.com/
 * @author     monika.gujar@greenpointglobal.com
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
$string['pluginname'] = 'TG Whiteboard';
$string['live_session_name'] = 'Live Session Name';
$string['modulename']='TG Live Session';
$string['session_key']='Session Key';
$string['generalconfig']='General Whiteboard Configuration';
$string['client_name']='Client Name';
$string['license_key']='License Key';
$string['room_name']='Room Name';
$string['is_secured']='Is_Secured';
$string['explaingeneralconfig'] = 'Whiteboard Settings :- Required for authentication';
$string['setting_discription']='TG Campus™ offers a state-of-the-art online tutoring platform, with the best Learning Management System (LMS) for tutors and institutes. Students have an opportunity to study in an environment beyond the confines of the four walls of a classroom, with features that creates an interactive learning experience. Live Online Class Sessions (HD quality), digital whiteboard, tests and assessments, scheduling and monitoring are some of the various features of our platform. We provide tutors with the added advantage of one-on-one or group tutoring sessions aided with multiple types of teaching aids, without the real-life hassles of maintaining a large physical classroom.';
$string['host_session']='Host';
$string['join_session']='Join';
$string['presenter_id']='Select Teacher';
$string['student_id']='Select Students';
$string['play_recording']='Play Recording';
$string['modulenameplural']='TGWhiteboard';
$string['sdate']='Start Date & Time';
$string['teacher_students']='Select Teacher and Students';
$string['session_details']='Session Details';
$string['modulename_help'] = 'TG Campus™ offers a state-of-the-art online tutoring platform, with the best Learning Management System (LMS) for tutors and institutes. Students have an opportunity to study in an environment beyond the confines of the four walls of a classroom, with features that creates an interactive learning experience. Live Online Class Sessions (HD quality), digital whiteboard, tests and assessments, scheduling and monitoring are some of the various features of our platform. We provide tutors with the added advantage of one-on-one or group tutoring sessions aided with multiple types of teaching aids, without the real-life hassles of maintaining a large physical classroom.';
$string['tg_duration']='Duration (in minutes)';
$string['startdt_error']='Can not select passed Date / Time';
$string['name_error']='Name already exists';