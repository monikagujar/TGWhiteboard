<?php
// This file is part of TGCampusWhiteboard - https://www.tgcampus.com/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * The main tgwhiteboard configuration form
 *
 * It uses the standard core Moodle formslib. For more info about them, please
 * visit: http://docs.moodle.org/en/Development:lib/formslib.php
 *
 * @package    mod_tgwhiteboard
 * @copyright  https://www.tgcampus.com/
 * @author     monika.gujar@greenpointglobal.com 
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
if (!defined('MOODLE_INTERNAL')) {
    die('Direct access to this script is forbidden.');    ///  It must be included from a Moodle page
}
global $CFG, $OUTPUT, $COURSE, $USER, $DB, $PAGE, $RECORD;
require_once("$CFG->libdir/formslib.php");
require_once($CFG->dirroot.'/course/moodleform_mod.php');
require_once($CFG->dirroot.'/mod/tgwhiteboard/lib.php');
require_once($CFG->dirroot.'/mod/tgwhiteboard/locallib.php');
require_once(dirname(dirname(dirname(__FILE__))) . '/config.php');
require_once(dirname(__FILE__) . '/lib.php');
require_once('locallib.php');
require_once('lib.php');
require_once($CFG->dirroot . '/lib/dml/moodle_database.php');
$PAGE->requires->jquery(); 
class mod_tgwhiteboard_mod_form extends moodleform_mod { 
    function definition() { 
	global $CFG, $OUTPUT, $COURSE, $USER, $DB, $PAGE, $RECORD;
	
        $mform = $this->_form; 
		$tgconfig = get_config('mod_tgwhiteboard');
		$mform->addElement('header', 'session_details', get_string('session_details', 'tgwhiteboard'));
        $mform->addElement('text', 'name', get_string('live_session_name', 'tgwhiteboard'));
        $mform->setType('name', PARAM_TEXT);
        $mform->addRule('name', null, 'required', null, 'client');		
		$loggedin_user = $USER->id;
		$query_string = http_build_query($_GET);
		if (strpos($query_string, 'update') !== false) {			
			 $tgwhiteboard= $DB->get_record('tgwhiteboard', array('id'=>$this->current->id), '*', IGNORE_MISSING);			 
			 $tg_students= $DB->get_records('tg_students', array('tgwhiteboard_id'=>$this->current->id));
			 
			$mform->addElement('date_time_selector', 'startdt', get_string('sdate','tgwhiteboard'));	
			$mform->setDefault('startdt',  $tgwhiteboard->tg_start_datetime);
			$mform->addRule('startdt', null, 'required', null, 'client');
			
			$mform->addElement('text', 'tg_duration', get_string('tg_duration', 'tgwhiteboard'));
			$mform->setDefault('tg_duration',  $tgwhiteboard->tg_duration);
				$mform->setType('tg_duration', PARAM_INT);
				$mform->addRule('tg_duration', get_string('tg_duration', 'tgwhiteboard'), 'required', null, 'client', true);
			
			$mform->addElement('header', 'teacherstudents', get_string('teacher_students', 'tgwhiteboard'));
			$teacherdetail = tgwhiteboard_getteacherdetail();
            $teacher = array();
            foreach ($teacherdetail as $value) {
            $teacher[$value->id] = $value->username;
            }
			$mform->addElement('select', 'presenter_id', get_string('presenter_id', 'tgwhiteboard'), $teacher);
				
				$studentdetail = tgwhiteboard_getstudentdetail();
				$student = array();
				foreach ($studentdetail as $key => $value) {
				$student[$value->id] = $value->username;
				$typeitem[] = &$mform->createElement('advcheckbox',$key, '', $student[$value->id], array('name' => $key,'group'=>1), $key);
				}
				
				foreach ($tg_students as $student)
			 {
				if($student->tg_studentid != 0) {
                    $mform->setDefault("types[$student->tg_studentid]", true);
                }
				else {
                    $mform->setDefault("types[$student->tg_studentid]", false);
                } 
			 }
				
				$mform->addGroup($typeitem, 'types',get_string('student_id', 'tgwhiteboard'));
				$this->add_checkbox_controller(1, null, null, 1);	
			}
			else
			{				
				$mform->addElement('date_time_selector', 'startdt', get_string('sdate','tgwhiteboard'));
				$mform->addRule('startdt', null, 'required', null, 'client');
				
				$mform->addElement('text', 'tg_duration', get_string('tg_duration', 'tgwhiteboard'));
				$mform->setType('tg_duration', PARAM_INT);
				$mform->addRule('tg_duration', get_string('tg_duration', 'tgwhiteboard'), 'required', null, 'client', true);
				
				$mform->addElement('header', 'teacherstudents', get_string('teacher_students', 'tgwhiteboard'));
				$mform->setExpanded('teacherstudents', false);
				$teacherdetail = tgwhiteboard_getteacherdetail();
                $teacher = array();
                foreach ($teacherdetail as $value) {
                    $teacher[$value->id] = $value->username;
                }
				$selectteacher = $mform->addElement('select', 'presenter_id', get_string('presenter_id', 'tgwhiteboard'), $teacher);
				$selectteacher->setSelected($loggedin_user);
				
				$studentdetail = tgwhiteboard_getstudentdetail();
				$student = array();
				foreach ($studentdetail as $key => $value) {
				$student[$value->id] = $value->username;
				$typeitem[] = &$mform->createElement('advcheckbox',$key, '', $student[$value->id], array('name' => $key,'group'=>1), $key);
				$mform->setDefault("types[$key]", true);
			}
				$mform->addGroup($typeitem, 'types',get_string('student_id', 'tgwhiteboard'));
				$this->add_checkbox_controller(1, null, null, 1);
			} 	
			
		$this->standard_coursemodule_elements(); 
        $this->add_action_buttons();			
    }

function validation($data, $files) {
	global $CFG, $OUTPUT, $COURSE, $USER, $DB, $PAGE, $RECORD;
    $errors = parent::validation($data, $files);
	
    if ($data['startdt'] < time()) {
        $errors['startdt'] = get_string('startdt_error', 'tgwhiteboard');
    }
	
	$session_name=tgwhiteboard_getsessiondetail();
	foreach($session_name as $session)
	{
		if ($data['name'] == $session->name and $this->current->id != $session->id) {
			$errors['name'] = get_string('name_error', 'tgwhiteboard');
		}
	}
	return $errors;
}
	
}