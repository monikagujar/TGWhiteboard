<?php
if (!defined('MOODLE_INTERNAL')) {
    die('Direct access to this script is forbidden.');    ///  It must be included from a Moodle page
}
global $CFG, $OUTPUT, $COURSE, $USER, $DB, $PAGE, $RECORD;
require_once("$CFG->libdir/formslib.php");
require_once($CFG->dirroot.'/course/moodleform_mod.php');
require_once($CFG->dirroot.'/mod/tgwhiteboard/lib.php');
require_once($CFG->dirroot.'/mod/tgwhiteboard/locallib.php');
require_once(dirname(dirname(dirname(__FILE__))) . '/config.php');
require_once(dirname(__FILE__) . '/lib.php');
require_once('locallib.php');
require_once('lib.php');
require_once($CFG->dirroot . '/lib/dml/moodle_database.php');
$PAGE->requires->jquery(); 
class mod_tgwhiteboard_mod_form extends moodleform_mod { 
    function definition() { 
	global $CFG, $OUTPUT, $COURSE, $USER, $DB, $PAGE, $RECORD;
	
        $mform = $this->_form; 
		
        $mform->addElement('text', 'name', get_string('live_session_name', 'tgwhiteboard'));
        $mform->setType('name', PARAM_TEXT);
        $mform->addRule('name', null, 'required', null, 'client');
		
		/* $mform->addElement('text', 'sessionkey', get_string('session_key', 'tgwhiteboard'));
		$mform->setType('sessionkey', PARAM_TEXT);
        $mform->addRule('sessionkey', null, 'required', null, 'client'); */
		
		$var=$mform->getElementValue('name');
		echo 'var' . $var;
		
		$query_string = http_build_query($_GET);

		if (strpos($query_string, 'update') !== false) {
			

			/* if ($defaults = $DB->get_record('tgwhiteboard', array('name'=>'sir')))
			{ */
				$mform->addElement('date_time_selector', 'startdt', get_string('sdat','tgwhiteboard'));	
				//$mform->setDefault('width', $tgconfig->startdt);
			//$defaulttime = make_timestamp(2018, 10, 29, 10, 30);
			//$mform->setDefault('startdt',  $defaulttime);
			
			$mform->addElement('date_time_selector', 'enddt', get_string('edat','tgwhiteboard'));
			//$defaulttime = make_timestamp(2018, 10, 29, 10, 30);
			//$mform->setDefault('enddt',  $defaulttime);
			
			$mform->addElement('header', 'teacherstudents', get_string('teacher_students', 'tgwhiteboard'));
			$mform->setExpanded('teacherstudents', false);
			$teacherdetail = tgwhiteboard_getteacherdetail();
            $teacher = array();
            foreach ($teacherdetail as $value) {
            $teacher[$value->id] = $value->username;
            }
			$mform->addElement('select', 'presenter_id', get_string('presenter_id', 'tgwhiteboard'), $teacher);
			$mform->addRule('presenter_id', null, 'required', null, 'client');			
				
				$studentdetail = tgwhiteboard_getstudentdetail();
				$student = array();
				foreach ($studentdetail as $key => $value) {
				$student[$value->id] = $value->username;
				$typeitem[] = &$mform->createElement('advcheckbox',$key, '', $student[$value->id], array('name' => $key,'group'=>1), $key);
				$mform->setDefault("types[$key]", true);
				}
				$mform->addGroup($typeitem, 'types',get_string('student_id', 'tgwhiteboard'));
				$this->add_checkbox_controller(1);
			//}
			}
			else
			{
				$mform->addElement('date_time_selector', 'startdt', get_string('sdat','tgwhiteboard'));	
		
				$mform->addElement('date_time_selector', 'enddt', get_string('edat','tgwhiteboard'));	
				$mform->addElement('header', 'teacherstudents', get_string('teacher_students', 'tgwhiteboard'));
				$mform->setExpanded('teacherstudents', false);
				$teacherdetail = tgwhiteboard_getteacherdetail();
                $teacher = array();
                foreach ($teacherdetail as $value) {
                    $teacher[$value->id] = $value->username;
                }
				$mform->addElement('select', 'presenter_id', get_string('presenter_id', 'tgwhiteboard'), $teacher);
				$mform->addRule('presenter_id', null, 'required', null, 'client');
				
			 /* $studentdetail = tgwhiteboard_getstudentdetail();
                $student = array();
                //$student['select'] = 'Select Student';
                foreach ($studentdetail as $value) {
                    $student[$value->id] = $value->username;
                }                
				$mform->addElement('select', 'student_id', get_string('student_id', 'tgwhiteboard'), $student)->setMultiple(true);
				$mform->addRule('student_id', null, 'required', null, 'client'); */
				
				$studentdetail = tgwhiteboard_getstudentdetail();
				$student = array();
				foreach ($studentdetail as $key => $value) {
				$student[$value->id] = $value->username;
				$typeitem[] = &$mform->createElement('advcheckbox',$key, '', $student[$value->id], array('name' => $key,'group'=>1), $key);
				$mform->setDefault("types[$key]", true);
			}
				$mform->addGroup($typeitem, 'types',get_string('student_id', 'tgwhiteboard'));
				$this->add_checkbox_controller(1);
			} 
        $this->standard_coursemodule_elements(); 
        $this->add_action_buttons();			
    }
	
}