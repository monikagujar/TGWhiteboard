<?php
require('../../config.php');
require_once('lib.php');
defined('MOODLE_INTERNAL') || die();

global $CFG, $DB, $PAGE, $OUTPUT, $USER, $RECORD;

$cmid = required_param('id', PARAM_INT);
echo $cmid;
$cm = get_coursemodule_from_id('tgwhiteboard', $cmid, 0, false, MUST_EXIST);


 $PAGE->set_url('/mod/tgwhiteboard/view.php', array('id' => $cm->id));
 $pagetitle = $PAGE->set_title('My modules page title');
 $header = $PAGE->set_heading('View Page');
 $PAGE->set_pagelayout('standard');
 echo $OUTPUT->header($header); 
 
 $livesessiondetails = $DB->get_record('tgwhiteboard', ['name' => $cm->name]);
  
 $studentdetails = $DB->get_record('tg_students', ['tgwhiteboard_id' => $livesessiondetails->id]);

 $host = $livesessiondetails->presenter_id;
 $join = $studentdetails->tg_studentid;
  
$version = get_config('mod_tgwhiteboard');

$tgwhiteboard_room_name = $DB->get_record_sql('SELECT * FROM {config} WHERE name = ?', array('tgwhiteboard_room_name'));
$tg_room = $tgwhiteboard_room_name->value;

$tgwhiteboard_license_key = $DB->get_record_sql('SELECT * FROM {config} WHERE name = ?', array('tgwhiteboard_license_key'));
$tg_license = $tgwhiteboard_license_key->value;

$tgwhiteboard_client_name = $DB->get_record_sql('SELECT * FROM {config} WHERE name = ?', array('tgwhiteboard_client_name'));
$tg_client = $tgwhiteboard_client_name->value;

$tgwhiteboard_is_secured = $DB->get_record_sql('SELECT * FROM {config} WHERE name = ?', array('tgwhiteboard_is_secured'));
$tg_secured = $tgwhiteboard_is_secured->value;

$tg_status = $DB->get_record('tg_status', ['id' => $cm->id]);
 
$session_start = date('Y-m-d h:i', $livesessiondetails->tg_start_datetime);
//echo 'session_start ' . $session_start . '</br>';
$session_end = date('Y-m-d h:i', $livesessiondetails->tg_end_datetime);
//echo 'session_end ' . $session_end . '</br>';

$current_datetime = date('Y-m-d h:i') . '</br>';

$duration = round((strtotime($session_end) - strtotime($session_start))/60, 1);

$start_time = strtotime($session_start);
$start_time = $start_time - (15 * 60);
$start_time = date("Y-m-d h:i", $start_time);
//echo 'start_time ' . $start_time . '</br>';

$end_time = strtotime($session_end);
$end_time = $end_time + (15 * 60);
$end_time = date("Y-m-d h:i", $end_time);
//echo 'end_time ' . $end_time;

$show_rec = strtotime($session_end);
$show_rec = $show_rec + (30 * 60);
$show_rec = date("Y-m-d h:i", $show_rec);
 
$table = new html_table();
$table->head = array('Live Session Name', 'Start Date & Time', 'End Date & Time');
$table->data[] = array($cm->name,$session_start,$session_end);
echo html_writer::table($table);

 //if(user_has_role_assignment($USER->id,$join))
	if ($join == $USER->id) 
 {
	 if($start_time <= $current_datetime and $current_datetime <= $end_time)
	 {
		 $link_join = new moodle_url('https://live.tgcampus.com/develop/custom/', array('ClientID' => $tg_license,'RoomName' => $tg_room,'Rec' => $cm->name,'Participant' => $USER->id,'Host' => $livesessiondetails->presenter_id, 'SessionKey' => $livesessiondetails->tg_sessionkey ));
echo html_writer::link($link_join, get_string('join_session', 'tgwhiteboard'), ['class' => 'btn btn-primary']);
	 }
	 
 }
else if ($host == $USER->id)
	{
		if($start_time <= $current_datetime and $current_datetime <= $end_time)
		{
         
		  $link_host = new moodle_url('https://live.tgcampus.com/develop/custom/', array('ClientID' => $tg_license,'RoomName' => $tg_room,'Rec' => $cm->name,'Host' => $livesessiondetails->presenter_id, 'SessionKey' => $livesessiondetails->tg_sessionkey, 'duration'=>$duration ));
echo html_writer::link($link_host, get_string('host_session', 'tgwhiteboard'), ['class' => 'btn btn-primary']);
            
		}			
	
 }
 
/*  echo 'rec' . $show_rec . '</br>';
 echo 'current' . $current_datetime; */

  if ($show_rec < $current_datetime)
  {
	$link_play = new moodle_url('https://live.tgcampus.com/develop/custom/ClientRecording.html', array('Rec' => $cm->name,'RoomName' => $tg_room,'FileName' => 'P_'.$tg_room.'_'.$cm->name ));
	echo html_writer::link($link_play, get_string('play_recording', 'tgwhiteboard'), ['class' => 'btn btn-primary']);
  }
  
  
echo $OUTPUT->footer();