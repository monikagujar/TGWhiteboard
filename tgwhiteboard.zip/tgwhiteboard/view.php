<?php
// This file is part of TGCampusWhiteboard - https://www.tgcampus.com/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
/**
 * Prints a particular instance of tgwhiteboard
 *
 * You can have a rather longer description of the file as well,
 * if you like, and it can span multiple lines.
 *
 * @package    mod_tgwhiteboard
 * @subpackage tgwhiteboard
 * @copyright  https://www.tgcampus.com/
 * @author     monika.gujar@greenpointglobal.com
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
require('../../config.php');
require_once('lib.php');
defined('MOODLE_INTERNAL') || die();

global $CFG, $DB, $PAGE, $OUTPUT, $USER, $RECORD;

$cmid = required_param('id', PARAM_INT);
$cm = get_coursemodule_from_id('tgwhiteboard', $cmid, 0, false, MUST_EXIST);
$course = $DB->get_record('course', array('id' => $cm->course), '*', MUST_EXIST);

require_login($course, true, $cm);
 $PAGE->set_url('/mod/tgwhiteboard/view.php', array('id' => $cm->id));
 $pagetitle = $PAGE->set_title('TG Live Session');
 $header = $PAGE->set_heading('Live Session Details');
 $PAGE->set_pagelayout('standard');
 echo $OUTPUT->header($header); 
 
 $livesessiondetails = $DB->get_record('tgwhiteboard', ['name' => $cm->name]);
 $studentdetails= $DB->get_records('tg_students', array('tgwhiteboard_id'=>$livesessiondetails->id));  

 $tg_duration = $livesessiondetails->tg_start_datetime + ($livesessiondetails->tg_duration*60);
 
 $host = $livesessiondetails->presenter_id;
 
$tgwhiteboard_room_name = $DB->get_record_sql('SELECT * FROM {config} WHERE name = ?', array('tgwhiteboard_room_name'));
$tg_room = $tgwhiteboard_room_name->value;

$tgwhiteboard_license_key = $DB->get_record_sql('SELECT * FROM {config} WHERE name = ?', array('tgwhiteboard_license_key'));
$tg_license = $tgwhiteboard_license_key->value;
 
$session_start = date('Y-m-d H:i', $livesessiondetails->tg_start_datetime);
$session_end = date('Y-m-d H:i', $tg_duration);

$current_datetime = date('Y-m-d H:i');

$start_time = strtotime($session_start); // converts to Unix timestamp
$start_time = $start_time - (15 * 60);
$start_time = date("Y-m-d H:i", $start_time); // converts to Unix timestamp

$end_time = strtotime($session_end);
$end_time = $end_time + (15 * 60);
$end_time = date("Y-m-d H:i", $end_time);

$show_rec = strtotime($session_end);
$show_rec = $show_rec + (30 * 60);
$show_rec = date("Y-m-d H:i", $show_rec);

if ($start_time < $current_datetime)
{
	$duration = round((strtotime($end_time) - strtotime($current_datetime))/60, 1);
}
else
{
	$duration = round((strtotime($end_time) - strtotime($start_time))/60, 1);
}

$tgduration = round((strtotime($session_end) - strtotime($session_start))/60, 1);
 
$table = new html_table();
$table->head = array('Live Session Name', 'Start Date & Time', 'End Date & Time', 'Duartion (in minutes)');
$table->data[] = array($cm->name,$session_start,$session_end, $tgduration);
echo html_writer::table($table);

	 $sql  = "SELECT DISTINCT u.username FROM {user} u ";
     $sql .= "JOIN {tgwhiteboard} tg ON u.id = tg.presenter_id ";
     $sql .= "WHERE tg.presenter_id in (" . $livesessiondetails->presenter_id . ')';
	 
	$teacherlist = $DB->get_records_sql($sql);
	 $teacher_username = array_values($teacherlist)[0];
	 
	if($start_time <= $current_datetime and $current_datetime <= $end_time)
	 {
	foreach ($studentdetails as $join)
	{
	if ($join->tg_studentid == $USER->id) 
 {
	 $end_date_time = strtotime($end_time);
		
		 $link_join = new moodle_url('https://live.tgcampus.com/develop/custom/', array('ClientID' => $tg_license,'RoomName' => $tg_room,'Rec' => $cm->name,'Participant' => $USER->username,'Host' => $teacher_username->username, 'SessionKey' => $livesessiondetails->tg_sessionkey, 'duration'=>$duration, 'end_time'=>$end_date_time ));
		 echo html_writer::link($link_join, get_string('join_session', 'tgwhiteboard'), ['class' => 'btn btn-primary', 'target' => '_blank']);	 
 }
	}

if ($host == $USER->id)
	{
		$end_date_time = strtotime($end_time);
		
		$link_host = new moodle_url('https://live.tgcampus.com/develop/custom/', array('ClientID' => $tg_license,'RoomName' => $tg_room,'Rec' => $cm->name,'Host' => $USER->username, 'SessionKey' => $livesessiondetails->tg_sessionkey, 'duration'=>$duration, 'end_time'=>$end_date_time ));
		echo html_writer::link($link_host, get_string('host_session', 'tgwhiteboard'), ['class' => 'btn btn-primary', 'target' => '_blank']);
     }	 
	 }
 if (!is_siteadmin())
 {
	 if ($show_rec < $current_datetime)
  {
	$link_play = new moodle_url('https://live.tgcampus.com/develop/custom/ClientRecording.html', array('Rec' => $cm->name,'RoomName' => $tg_room,'FileName' => 'P_'.$tg_room.'_'.$cm->name, 'duration'=>$duration ));
	echo html_writer::link($link_play, get_string('play_recording', 'tgwhiteboard'), ['class' => 'btn btn-primary', 'target' => '_blank']);
 }
 }

echo $OUTPUT->footer();